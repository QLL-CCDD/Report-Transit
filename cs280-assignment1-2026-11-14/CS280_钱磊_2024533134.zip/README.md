# CS280 Assignment1 is Released

**IMPORTANT:** This assignment is due on **Saturday, Nov 14, 2026 at 23:59 Beijing Time**. All submitted code will be checked for plagiarism.

**REMINDER:** You have a total of **7 slip days** for all homework assignments and no more than **4 slip days** can be used for assignment1.

`CS280-Fall26-Assignment1.zip` has been added to the class resources page under **Homework**, download from this [link](https://piazza.com/class_profile/get_resource/mtzzl4urnz8797/mvcbrxomazy4gw)

## Submission Guidelines

You need to submit **two items** for assignment1:

### 1. Gradescope Submission

- Register on Gradescope ([www.gradescope.com](https://www.gradescope.com)) using entry code **K88PKK** and your school email.
- Convert your answers for **Part A** and all **five notebooks** from **Part B** into PDF format, then combine them into a **single PDF file**.
- Submit the PDF on Gradescope and **match the PDF pages to each question**.

### 2. ShanghaiTech EPAN Submission

- Compress and package your entire assignment. For Part B, you can run `python collect_submission.py` to collect your notebooks and source code (the CIFAR-10 dataset is excluded automatically).
- Name the zip file as `CS280_[Your Full Name]_[Your student ID].zip`.
- Upload the zip file to the ShanghaiTech network disk: <https://epan.shanghaitech.edu.cn/l/TFUBdT>
