# CS280 Homework 1 · Part B

这部分用 NumPy 手写神经网络的前向传播和反向传播，实现基础的 MLP 和 CNN。

Part B 共 **80 分**，与 Part A 的 20 分合计 **100 分**。各题分值如下，包含代码实现、notebook 中的实验和文字回答。

| 顺序 | 分值 | Notebook | 主要实现位置 | 内容 |
| --- | ---: | --- | --- | --- |
| Q1 | 15 分 | `q1_two_layer_net.ipynb` | `models/layers.py`、`models/fc_net.py` | affine、ReLU、softmax loss、TwoLayerNet |
| Q2 | 20 分 | `q2_fully_connected_net.ipynb` | `models/fc_net.py`、`utils/optim.py` | 任意深度全连接网络、Momentum / RMSProp / Adam、调参 |
| Q3 | 20 分 | `q3_batch_normalization.ipynb` | `models/layers.py`、`models/fc_net.py` | BatchNorm、LayerNorm，初始化和 batch size 实验 |
| Q4 | 5 分 | `q4_dropout.ipynb` | `models/layers.py`、`models/fc_net.py` | Inverted Dropout，训练 / 推理模式与过拟合 |
| Q5 | 20 分 | `q5_convolutional_networks.ipynb` | `models/layers.py`、`models/cnn.py` | 卷积、池化、CNN、Spatial BatchNorm、GroupNorm |

## 项目结构

```text
assignment1_partB/
├── q1_two_layer_net.ipynb ... q5_convolutional_networks.ipynb
├── models/
│   ├── fc_net.py               # TwoLayerNet 和 FullyConnectedNet
│   ├── cnn.py                  # ThreeLayerConvNet
│   ├── layers.py               # 需要实现的基础层
│   ├── layer_utils.py          # 组合层，例如 affine + ReLU
│   └── fast_layers.py / im2col* / setup.py  # 已提供的卷积加速实现
├── datasets/
│   ├── cifar10.py              # 数据加载和预处理
│   └── download.py             # 下载 CIFAR-10
├── utils/
│   ├── solver.py / optim.py    # 训练循环和优化器（Q2 完成）
│   └── gradient_check.py / visualization.py
├── assets/                    # 卷积可视化用的小图片
├── requirements.txt
└── collect_submission.py
```

## 运行

推荐 Python 3.11。在本目录启动 Jupyter 或者使用 VS Code 打开该目录，并选用安装了依赖的 Python 内核：

```bash
python -m datasets.download
jupyter lab # 或者使用 VS Code 打开该目录
```

Q5 的 **Fast Layers** 部分需要编译 Cython 扩展。除 `requirements.txt` 中的 Cython、NumPy 和 setuptools 外，还需要系统 C 编译器：

- Windows：安装 Visual Studio Build Tools，勾选 **Desktop development with C++（使用 C++ 的桌面开发）**，包含 MSVC 和 Windows SDK。
- macOS：安装 Xcode Command Line Tools（`xcode-select --install`）。
- Linux：安装 GCC 等编译工具，例如 Ubuntu / Debian 的 `build-essential`。

准备好后，运行 Q5 的编译 cell。它使用当前 notebook 内核的 Python 在 `models/` 下编译，并自动重新加载 `fast_layers`，首次编译后通常无需重启内核。如果更换 Python / NumPy 环境，或重新编译了已加载的扩展，请重启内核并重新运行 notebook。

按 Q1–Q5 顺序完成 notebook 和 Python 文件中的实现、文字回答，保留自己运行得到的输出。数据集位于 `datasets/cifar-10-batches-py/`。


## 提交

按照仓库根目录 [README.md](../../README.md) 的要求，本次作业需要分别提交 PDF 和代码压缩包。

### 1. PDF：提交到 Gradescope

先运行并保存 Part B 的五个 notebook，确保 PDF 中包含代码、文字回答、运行结果和图表。将每个 notebook 导出为 PDF，按 **Q1–Q5** 顺序拼接，再与 **Part A** 的答案合并为一个 PDF 文件。

VS Code 的 notebook 编辑器和 Jupyter 都提供导出工具，可以选择导出 PDF 或 HTML。若无法直接导出 PDF，也可以先导出 HTML，用浏览器打开后，**右键 → 打印 → 保存为 PDF**。导出后检查公式、图表和代码是否完整，有没有被截断，再使用 PDF 合并工具拼接。

将最终的单个 PDF 上传到 Gradescope，并为每道题指定对应的 PDF 页码。注册码等信息见根目录 README。

### 2. 代码压缩包：提交到上科大网盘

保存 notebook 后，在本目录运行：

```bash
python collect_submission.py
```

脚本生成 `submission.zip`，包含 Part B 的五个 notebook、源代码和必要的小资源，不包含数据集、模型权重或编译产物。脚本只打包已保存的文件，不运行 notebook，也不导出或合并 PDF。

将 Part B 的提交文件与 Part A 等本次作业材料一起打包，最终压缩包命名为 `CS280_[Your Full Name]_[Your student ID].zip`，上传到 [上科大网盘](https://epan.shanghaitech.edu.cn/l/TFUBdT)。

## 常用的代码框架

本次作业使用 NumPy 和 notebook，需要手动处理各层的计算和反向传播，现在有很多好用的工具，可以省去训练模型时重复写代码的工作，以后做项目时可以按需要选用。

- [PyTorch](https://pytorch.org/docs/stable/index.html)：提供常用网络层、损失函数和优化器，支持 GPU 计算，也能自动计算梯度。
- [Accelerate](https://huggingface.co/docs/accelerate/index), [Lightning](https://lightning.ai/docs/pytorch/stable/)：都是基于 PyTorch 的训练框架，帮助你组织训练与验证流程，并简化模型保存、混合精度和多 GPU 训练等工作。
- [TensorBoard](https://www.tensorflow.org/tensorboard), [Weights & Biases（W&B）](https://docs.wandb.ai/)：记录和查看 loss、accuracy 等训练曲线，也方便比较不同实验。
