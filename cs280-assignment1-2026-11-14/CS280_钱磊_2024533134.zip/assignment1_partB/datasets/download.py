"""Download the official CIFAR-10 Python archive into this directory."""

from pathlib import Path
import hashlib
import tarfile
from urllib.request import urlretrieve

URL = "https://www.cs.toronto.edu/~kriz/cifar-10-python.tar.gz"
MD5 = "c58f30108f718f92721af3b95e74349a"


def main():
    root = Path(__file__).resolve().parent
    archive = root / "cifar-10-python.tar.gz"
    if not archive.exists():
        print("Downloading CIFAR-10...")
        urlretrieve(URL, archive)
    digest = hashlib.md5()
    with archive.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    if digest.hexdigest() != MD5:
        raise ValueError(f"Checksum mismatch; remove {archive} and retry.")
    with tarfile.open(archive) as tar:
        for member in tar.getmembers():
            target = (root / member.name).resolve()
            if root not in target.parents or not (member.isfile() or member.isdir()):
                raise ValueError(f"Unexpected archive member: {member.name}")
        tar.extractall(root)
    print("CIFAR-10 is ready in", root / "cifar-10-batches-py")


if __name__ == "__main__":
    main()
