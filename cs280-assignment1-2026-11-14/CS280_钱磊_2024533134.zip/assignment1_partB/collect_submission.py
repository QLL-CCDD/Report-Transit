"""Collect saved notebooks and source files into submission.zip."""

from pathlib import Path
import sys
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parent
NOTEBOOKS = (
    "q1_two_layer_net.ipynb",
    "q2_fully_connected_net.ipynb",
    "q3_batch_normalization.ipynb",
    "q4_dropout.ipynb",
    "q5_convolutional_networks.ipynb",
)


def source_files():
    files = [ROOT / name for name in NOTEBOOKS]
    files += [ROOT / name for name in (
        "README.md", "requirements.txt",
        "collect_submission.py",
    )]
    for folder in ("models", "datasets", "utils"):
        files += [p for p in (ROOT / folder).iterdir()
                  if p.is_file() and p.suffix in (".py", ".pyx")]
    files += [p for p in (ROOT / "assets").iterdir() if p.is_file()]
    missing = [str(p.relative_to(ROOT)) for p in files if not p.is_file()]
    if missing:
        raise RuntimeError("Missing required files: " + ", ".join(missing))
    return sorted(files)


def main():
    try:
        files = source_files()
        # Replace the previous ZIP only after the new archive is complete.
        with tempfile.TemporaryDirectory(prefix=".submission-", dir=ROOT) as temp:
            archive_path = Path(temp) / "submission.zip"
            with ZipFile(archive_path, "w", ZIP_DEFLATED) as archive:
                for path in files:
                    archive.write(path, path.relative_to(ROOT))
            archive_path.replace(ROOT / "submission.zip")
        print("Submission ZIP:", ROOT / "submission.zip")
    except (RuntimeError, OSError) as exc:
        print("Submission packaging failed: " + str(exc), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
